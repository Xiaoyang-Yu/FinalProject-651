const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  publicPath:'./',
  // devServer: {
  //   proxy:"http://172.16.2.96:9000"
  // }
  devServer:{
    proxy:{
      '/yxy': {
        target:'http://172.16.2.77:8090',//后台接口地址
        pathRewrite:{'^/yxy':''},
        changeOrigin:true
      }
    }
  }
})
