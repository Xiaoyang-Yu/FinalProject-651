<template>
  <div style="width:1366px; margin: 0 auto; padding-top: 40px">
    <div class="flexbetween">
    <el-form :inline="true" class="demo-form-inline">
      <el-form-item label="零件id">
        <el-input v-model="partsId" placeholder="零件id"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="getByKey">查询</el-button>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="getByKey('reset')">重置</el-button>
      </el-form-item>
    </el-form>
    <el-upload
        style="margin-top: 10px"
        class="upload-demo"
        action="#"
        :on-preview="handlePreview"
        :on-remove="handleRemove"
        :before-remove="beforeRemove"
        :on-change="handleChange"
        multiple
        :auto-upload="false"
        :on-exceed="handleExceed"
        :file-list="fileList">
      <el-button size="small" type="primary">点击上传</el-button>
      <!--	<div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>-->
    </el-upload>
    </div>
    <el-table
        :data="tableData"
        border
        style="width: 100%">

      <el-table-column
          label="序号"
          type="index"
          align="center"
          width="50">
      </el-table-column>

      <el-table-column
          prop="id"
          label="id"
          align="center"
          width="300">
      </el-table-column>

      <el-table-column
          prop="message"
          label="描述"
          align="center"
          width="765">
      </el-table-column>

      <el-table-column
          label="操作"
          align="center"
          width="250">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="open(scope.row)">编辑</el-button>
          <el-button @click="deleteByKey(scope.row)" type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="PageWrap_List">
      <el-pagination @size-change="sizeChange"
                     @current-change="currentchange_list"
                     :current-page="currentpage_list"
                     :page-sizes="[5,10,15,20,50,100]"
                     :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper"
                     :total="totalCount_list">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      load:false,
      list:[],
      pageSize: 10,
      currentpage_list: 1,
      totalCount_list: 0,
      fileList: [],
      tableData: [{
        id: 'AAA-077',
        message: 'ORDER A-407-PC'
      }, {
        id: 'AAA-133',
        message: 'ORD WATER PIPE 1/2X92'
      }],
      partsId:"",
    }
  },
  methods: {
    open(data) {
      console.log(data)
      this.$prompt(`当前修改的值:${data.message}`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        this.updateDetail(data,value)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消输入'
        });
      });
    },
    handleRemove (file, fileList) {
      console.log(file, fileList)
    },
    handleChange (param) {
      this.load = true
      this.fileList = []
      // 组装数据
      const formData = new FormData()
      formData.append('file', param.raw)
      console.log(param)
      const isJPG = param.raw.type === 'text/plain'
      const isLt2M = param.raw.size / 1024 / 1024 < 2
      if (!isJPG) {
        this.$message.error('只能上传txt')
        this.fileList = []
      } else if (!isLt2M) {
        this.$message.error('大小不能超过 2MB!')
        this.fileList = []
      } else {
        this.load = true
        this.fileList = []
        // 组装传参数据
        // 请求后端接口
        this.$axios({
          method:'POST',
          url:'http://172.16.2.77:8080/yxy/parts/importTxt',
          data:formData,
        }).then(res => {
          console.log(res)
          this.load = false
          this.list=[]
          this.list = res.data
          // 附件展示的数据
        }).catch(() => {
          this.load = false
          this.$message.error('上传失败')
        })
      }
    },
    handlePreview (file) {
      console.log(this.fileList, file)
    },
    // eslint-disable-next-line no-unused-vars
    handleExceed (files, fileList) {
      this.$message.warning(`只允许上传一个文件!`)
    },
    // eslint-disable-next-line no-unused-vars
    beforeRemove (file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`)
    },
    currentchange_list (page) {
      this.currentpage_list = page
      this.getByKey()
    },
    sizeChange (size) {
      // 修改每页显示的数据条数
      this.pageSize = size
      // 修改当前页码为第一页
      this.currentpage_list = 1
      // 刷新表格数据
      this.getByKey()
    },
    getByKey(val){
      if(val ==='reset'){
        this.partsId = ''
      }
      this.$axios({
        method:'POST',
        url:'http://172.16.2.77:8080/yxy/parts/getByKey',
        data:{
          key:this.partsId,
          pageNo: this.currentpage_list,
          pageSize: this.pageSize
        }
      }).then(res=>{
        console.log(res)
        this.list = res.data.list
      }).catch(error=>{
        console.log(error)
      })
    },
    importTxt(){
      this.$axios({
        method:'POST',
        url:'http://172.16.2.77:8080/yxy/parts/importTxt',
        data:{
          name:'123',
          age:11
        }
      }).then(res=>{
        console.log(res)
        this.list = res.data.list
      }).catch(error=>{
        console.log(error)
      })
    },
    updateDetail(data,value){
      this.$axios({
        method:'POST',
        url:'http://172.16.2.77:8080/yxy/parts/updateDetail',
        data:{
          key:data.id,
          value:value
        }
      }).then(res=>{
        console.log(res)
        this.list = res.data.list
      }).catch(error=>{
        console.log(error)
      })
    },
    deleteByKey(row){
      this.$confirm('此操作将永久删除该条数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$axios({
          method:'POST',
          url:'http://172.16.2.77:8080/yxy/parts/deleteByKey',
          data:{
            key:row.id
          }
        }).then(res=>{
          console.log(res)
          this.list = res.data.list
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(error=>{
          console.log(error)
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })})
    },
    saveParts(){
      this.$axios({
        method:'POST',
        url:'http://172.16.2.77:8080/yxy/parts/saveParts',
        data:{
          name:'123',
          age:11
        }
      }).then(res=>{
        console.log(res)
        this.list = res.data.list
      }).catch(error=>{
        console.log(error)
      })
    }
  }
}

</script>

<style scoped>
.flexbetween{
  display: flex;
  display:-webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  -webkit-justify-content: space-between;
}
.PageWrap_List{
  width: 100%;
  margin: 15px auto;
  text-align: left;
}
</style>